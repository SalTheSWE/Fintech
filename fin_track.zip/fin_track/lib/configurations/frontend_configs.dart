import 'dart:ui';

class FrontendConfigs{
  static Color kAppPrimaryColor=const Color(0xff304FFE);
  static Color kAppSecondaryColor=const Color(0xffB8B8B8);
  static String kAppLogo="assets/images/app_logo.png";
}