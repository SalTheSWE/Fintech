package com.example.fin_track

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
